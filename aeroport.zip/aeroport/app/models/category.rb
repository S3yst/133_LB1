class Category < ApplicationRecord
  has_many :transactions
end
