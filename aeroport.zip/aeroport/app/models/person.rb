class Person < ApplicationRecord
    belongs_to :group
end
