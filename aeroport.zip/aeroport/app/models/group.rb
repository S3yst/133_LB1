class Group < ApplicationRecord
  has_many :people
end
