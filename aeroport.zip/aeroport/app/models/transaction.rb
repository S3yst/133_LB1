class Transaction < ApplicationRecord
  belongs_to :category
end
