module SchuelersHelper
end
