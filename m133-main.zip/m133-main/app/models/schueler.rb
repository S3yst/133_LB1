class Schueler < ApplicationRecord
  belongs_to :klasse
end
