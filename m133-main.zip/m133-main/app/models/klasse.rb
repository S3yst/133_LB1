class Klasse < ApplicationRecord
  has_many :schuelers
end
