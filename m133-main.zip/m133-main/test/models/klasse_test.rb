require "test_helper"

class KlasseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
