require "test_helper"

class SchuelerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
